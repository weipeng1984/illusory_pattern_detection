# To sort the data and make it easier to process

library(tidyverse)
library(dplyr)

# batch reading the data

filenames = list.files(path = getwd(), pattern = 'RDK_+.*csv')

# creating prolific id

prolific_id = substr(filenames, 5, 28)


# Writing the prolific id into the file

for (i in 1:length(prolific_id)) {
  df = read.csv(paste0('RDK_', prolific_id[i], '.csv'), header = TRUE, sep = ',', stringsAsFactors = FALSE)
  df[1, 1] = prolific_id[i]
  write.table(df, file = paste0('RDK_', prolific_id[i], '.csv'), sep = ",", col.names = TRUE,
              row.names = FALSE, qmethod = "double")
}

###################################################################################################

prolific_id_list = data.frame(prolific_id = character(), stringsAsFactors = FALSE)

for (i in 1:length(prolific_id)) {
  df = read.csv(paste0('RDK_', prolific_id[i], '.csv'), header = TRUE, sep = ",", stringsAsFactors = FALSE)
  
  prolific_id_list[i, 1] = df[1, 1]
}

write.table(prolific_id_list,
            file = paste0('prolific_id_list', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")

