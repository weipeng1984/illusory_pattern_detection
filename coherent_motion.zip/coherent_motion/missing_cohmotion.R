
# read prolific id in RDK files

df_coh = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# read prolific id in PLD files (after matching with survey)

df_bio = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)


df_coh = subset(df_coh, df_coh$prolific_id %in% df_bio$prolific_id)

write.table(df_coh, file = paste0('acc_total_filtered', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")



################################################################################
# This time we will try to find participants missing in RDK but not in PLD. 
# to be continue, we need to clear all the variables in the current working space

# read prolific id in RDK files

df_coh = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# read prolific id in PLD files (after matching with survey)

df_bio = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df_missing = df_bio$prolific_id[!(df_bio$prolific_id %in% df_coh$prolific_id)]

write.table(df_missing, file = "missing_detection_coh.csv", sep = ",", 
            col.names = TRUE, row.names = FALSE, qmethod = "double")

