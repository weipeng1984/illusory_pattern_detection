# ANCOVA

library(tidyverse)
library(afex)

# loading the data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# to calculate the false alarm rate

df$n_fa_rate = df$n_fa / (df$n_fa + df$n_cr)

# to calculate the z-score of false alarm rate
df$n_fa_rate = scale(df$n_fa_rate)[, 1]

# centering the fw, de and du

df$fw = as.numeric(scale(df$fw, scale = F))
df$de = as.numeric(scale(df$de, scale = F))
df$du = as.numeric(scale(df$du, scale = F))
df$rpbs = as.numeric(scale(df$rpbs, scale = F))

df$trb = as.numeric(scale(df$trb, scale = F))
df$psi = as.numeric(scale(df$psi, scale = F))
df$witchcraft = as.numeric(scale(df$witchcraft, scale = F))
df$superstition = as.numeric(scale(df$superstition, scale = F))
df$spiritualism = as.numeric(scale(df$spiritualism, scale = F))
df$elf = as.numeric(scale(df$elf, scale = F))
df$precognition = as.numeric(scale(df$precognition, scale = F))

attach(df)

# perform ANOVA using afex
aov.out = aov_ez(id = "id",
                 dv = "n_fa_rate", covariate = c('fw', 'de', 'du'),
                 within = c("mask"), factorize = FALSE, 
                 data = df, anova_table = list(es = "pes", correction = "none"))

aov.out$Anova
summary(aov.out)
knitr::kable(nice(aov.out))

