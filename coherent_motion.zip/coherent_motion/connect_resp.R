# batch reading the data

filenames_rdk = list.files(path = getwd(), pattern = 'RDK_+.*csv')

filenames_resp = list.files(path = getwd(), pattern = 'RESP_+.*csv')

# creating prolific id

prolific_rdk_id = substr(filenames_rdk, 5, 28)
prolific_resp_id = substr(filenames_resp, 6, 29)

# creating empty data.frame

rdk = data.frame(matrix(NA, nrow = 180, ncol = 6))
colnames(rdk) = c('trial_type', 'trial_index', 'number_of_dots', 'coherent_direction', 'coherence', 
                   'button_pressed')

# connect two files

for (i in 1:length(prolific_rdk_id)) {
  for (j in 1:length(prolific_resp_id)) {
    if (prolific_rdk_id[i] == prolific_resp_id[j]) {
      df_rdk = read.csv(paste0('RDK_', prolific_rdk_id[i], '.csv'), 
                        header = TRUE, sep = ',')
      df_resp = read.csv(paste0('RESP_', prolific_resp_id[j], '.csv'), 
                         header = TRUE, sep = ',')
      rdk[, 1] = df_rdk[, 4]
      rdk[, 2] = df_rdk[, 5]
      rdk[, 3] = df_rdk[, 1]
      rdk[, 4] = df_rdk[, 2]
      rdk[, 5] = df_rdk[, 3]
      rdk[, 6] = df_resp[, 1]
    }
  }
  write.table(rdk,
              file = paste0('rdk_', prolific_rdk_id[i], '.csv'), sep = ",", col.names = TRUE,
              row.names = FALSE, qmethod = "double")
}
