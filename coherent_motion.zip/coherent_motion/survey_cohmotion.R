# This is to connect survey data with rdk

# reading survey & point-light walker results

df_survey = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# reading the rdk

df_coh = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# finding the common part

common = intersect(df_survey$prolific_id, df_coh$prolific_id)

df_survey = subset(df_survey, df_survey$prolific_id %in% common)

df_coh = subset(df_coh, df_coh$prolific_id %in% common)

# starting to match based on prolific id

survey_coh = data.frame(session_id = character(), prolific_id = character(), response_id = character(),
                        fw = double(), de = double(), du = double(), rpbs = double(),
                        dprime = double(), c = double(), n_hit = double(), 
                        n_fa = double(), n_miss = double(), n_cr = double(),stringsAsFactors = FALSE)

for (i in 1:dim(df_survey)[1]) {
  for (j in 1:dim(df_coh)[1]) {
    if (df_survey[i, 3] == df_coh[j, 1]) {
      survey_coh[i, 1] = df_survey[i, 1]
      survey_coh[i, 2] = df_survey[i, 3]
      survey_coh[i, 3] = df_survey[i, 2]
      survey_coh[i, 4] = df_survey[i, 50]
      survey_coh[i, 5] = df_survey[i, 51]
      survey_coh[i, 6] = df_survey[i, 52]
      survey_coh[i, 7] = df_survey[i, 60]
      # beware of the column index in df_coh!!!!!!!
      survey_coh[i, 8] = df_coh[j, 8]
      # beware of the column index in df_coh!!!!!!
      survey_coh[i, 9] = df_coh[j, 12]
      survey_coh[i, 10] = df_coh[j, 2]
      survey_coh[i, 11] = df_coh[j, 3]
      survey_coh[i, 12] = df_coh[j, 4]
      survey_coh[i, 13] = df_coh[j, 5]
    }
  }
}

write.table(survey_coh, file = "sdt_407_stats_coh_survey.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")
