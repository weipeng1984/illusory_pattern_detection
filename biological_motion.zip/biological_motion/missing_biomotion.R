# This is to find out those participants who lack detection data

# Reading the original survey data 

df_survey = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

names(df_survey)[8] = 'ip'
names(df_survey)[9] = 'prolific_id'

# Reading the sorted id data (with matched session id)

df_id = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# Finding the missing biological motion data

df_missing = df_survey$prolific_id[!(df_survey$prolific_id %in% df_id$prolific_id)]

write.table(df_missing, file = "missing_detection_bio.csv", sep = ",", 
            col.names = TRUE, row.names = FALSE, qmethod = "double")
