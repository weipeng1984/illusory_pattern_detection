# selection based on exclusion result

# read stats data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# read exclusion results (exclusion_list)

df_excl = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

df = subset(df, (df$prolific_id %in% df_excl$prolific_id))


write.table(df, file = paste0('sdt_stats_bio_88_exclusion', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")
